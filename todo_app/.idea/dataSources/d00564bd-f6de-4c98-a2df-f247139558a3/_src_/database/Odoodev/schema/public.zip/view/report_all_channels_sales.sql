CREATE VIEW report_all_channels_sales AS
SELECT foo.id,
    foo.name,
    foo.partner_id,
    foo.product_id,
    foo.product_tmpl_id,
    foo.date_order,
    foo.user_id,
    foo.categ_id,
    foo.company_id,
    foo.price_total,
    foo.pricelist_id,
    foo.analytic_account_id,
    foo.country_id,
    foo.team_id,
    foo.price_subtotal,
    foo.product_qty
   FROM ( WITH currency_rate AS (
                 SELECT r.currency_id,
                    COALESCE(r.company_id, c.id) AS company_id,
                    r.rate,
                    r.name AS date_start,
                    ( SELECT r2.name
                           FROM res_currency_rate r2
                          WHERE ((r2.name > r.name) AND (r2.currency_id = r.currency_id) AND ((r2.company_id IS NULL) OR (r2.company_id = c.id)))
                          ORDER BY r2.name
                         LIMIT 1) AS date_end
                   FROM (res_currency_rate r
                     JOIN res_company c ON (((r.company_id IS NULL) OR (r.company_id = c.id))))
                )
         SELECT sol.id,
            so.name,
            so.partner_id,
            sol.product_id,
            pro.product_tmpl_id,
            so.date_order,
            so.user_id,
            pt.categ_id,
            so.company_id,
            (sol.price_total / COALESCE(cr.rate, 1.0)) AS price_total,
            so.pricelist_id,
            rp.country_id,
            (sol.price_subtotal / COALESCE(cr.rate, 1.0)) AS price_subtotal,
            ((sol.product_uom_qty / u.factor) * u2.factor) AS product_qty,
            so.analytic_account_id,
            so.team_id
           FROM ((((((((sale_order_line sol
             JOIN sale_order so ON ((sol.order_id = so.id)))
             LEFT JOIN product_product pro ON ((sol.product_id = pro.id)))
             JOIN res_partner rp ON ((so.partner_id = rp.id)))
             LEFT JOIN product_template pt ON ((pro.product_tmpl_id = pt.id)))
             LEFT JOIN product_pricelist pp ON ((so.pricelist_id = pp.id)))
             LEFT JOIN currency_rate cr ON (((cr.currency_id = pp.currency_id) AND (cr.company_id = so.company_id) AND (cr.date_start <= COALESCE((so.date_order)::timestamp with time zone, now())) AND ((cr.date_end IS NULL) OR (cr.date_end > COALESCE((so.date_order)::timestamp with time zone, now()))))))
             LEFT JOIN product_uom u ON ((u.id = sol.product_uom)))
             LEFT JOIN product_uom u2 ON ((u2.id = pt.uom_id)))) foo